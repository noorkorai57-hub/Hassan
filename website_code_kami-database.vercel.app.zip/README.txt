# WEBSITE CODE EXTRACTIONS REPORT 

Website: https://kami-database.vercel.app/aivideo.html
EXTRACTION DATE: 3443053.606201595

## Summary:
- HTML FILES: 1
- CSS FILES: 1
- INLINE CSS BLOCKS: 1
- JAVASCRIPT FILES: 2
- INLINE JAVASCRIPT BLOCKS: 0
- API ENDPOINTS FOUND: 1
- IMAGES FOUND: 2

## Files Structure:
- index.html (Main HTML file)
- css/ (All CSS files)
- js/ (All JavaScript files)
- api_endpoints.txt (List of found API endpoints)

## Note:
This extraction includes all publicly accessible code from the website.
Some dynamic content loaded via AJAX may not be included.
